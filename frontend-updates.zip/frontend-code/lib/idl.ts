export const IDL = {
  "address": "BYkMeRVSt8mvV2sxhd6eQhH5qp3JszfKimunZ7jDqpZA",
  "metadata": {
    "name": "leveraged_meme",
    "version": "0.1.0",
    "spec": "0.1.0"
  },
  "version": "0.1.0",
  "name": "leveraged_meme",
  "instructions": [
    {
      "name": "initializeToken",
      "accounts": [
        { "name": "creator", "isMut": true, "isSigner": true },
        { "name": "tokenMint", "isMut": true, "isSigner": true },
        { "name": "tokenState", "isMut": true, "isSigner": false },
        { "name": "feeVault", "isMut": true, "isSigner": false },
        { "name": "userReferral", "isMut": true, "isSigner": false },
        { "name": "curveTokenAccount", "isMut": true, "isSigner": true },
        { "name": "lpTokenAccount", "isMut": true, "isSigner": true },
        { "name": "systemProgram", "isMut": false, "isSigner": false },
        { "name": "tokenProgram", "isMut": false, "isSigner": false },
        { "name": "rent", "isMut": false, "isSigner": false },
        { "name": "clock", "isMut": false, "isSigner": false }
      ],
      "args": [
        { "name": "name", "type": "string" },
        { "name": "symbol", "type": "string" },
        { "name": "uri", "type": "string" },
        { "name": "leverage", "type": "u8" },
        { "name": "direction", "type": { "defined": "Direction" } },
        { "name": "underlying", "type": { "defined": "Underlying" } },
        { "name": "oraclePriceAtLaunch", "type": "u64" },
        { "name": "referrer", "type": { "option": "publicKey" } }
      ]
    },
    {
      "name": "buy",
      "accounts": [
        { "name": "buyer", "isMut": true, "isSigner": true },
        { "name": "tokenState", "isMut": true, "isSigner": false },
        { "name": "tokenMint", "isMut": true, "isSigner": false },
        { "name": "buyerTokenAccount", "isMut": true, "isSigner": false },
        { "name": "curveTokenAccount", "isMut": true, "isSigner": false },
        { "name": "feeVault", "isMut": true, "isSigner": false },
        { "name": "protocolFeeAccount", "isMut": true, "isSigner": false },
        { "name": "creatorFeeAccount", "isMut": true, "isSigner": false },
        { "name": "systemProgram", "isMut": false, "isSigner": false },
        { "name": "tokenProgram", "isMut": false, "isSigner": false },
        { "name": "clock", "isMut": false, "isSigner": false }
      ],
      "args": [{ "name": "amount", "type": "u64" }]
    },
    {
      "name": "sell",
      "accounts": [
        { "name": "seller", "isMut": true, "isSigner": true },
        { "name": "tokenState", "isMut": true, "isSigner": false },
        { "name": "tokenMint", "isMut": true, "isSigner": false },
        { "name": "sellerTokenAccount", "isMut": true, "isSigner": false },
        { "name": "curveTokenAccount", "isMut": true, "isSigner": false },
        { "name": "feeVault", "isMut": true, "isSigner": false },
        { "name": "protocolFeeAccount", "isMut": true, "isSigner": false },
        { "name": "creatorFeeAccount", "isMut": true, "isSigner": false },
        { "name": "systemProgram", "isMut": false, "isSigner": false },
        { "name": "tokenProgram", "isMut": false, "isSigner": false },
        { "name": "clock", "isMut": false, "isSigner": false }
      ],
      "args": [{ "name": "amount", "type": "u64" }]
    },
    {
      "name": "graduate",
      "accounts": [
        { "name": "authority", "isMut": true, "isSigner": true },
        { "name": "tokenState", "isMut": true, "isSigner": false },
        { "name": "tokenMint", "isMut": true, "isSigner": false },
        { "name": "pythOracle", "isMut": false, "isSigner": false },
        { "name": "systemProgram", "isMut": false, "isSigner": false },
        { "name": "clock", "isMut": false, "isSigner": false }
      ],
      "args": [{ "name": "currentOraclePrice", "type": "u64" }]
    },
    {
      "name": "setPause",
      "accounts": [
        { "name": "authority", "isMut": true, "isSigner": true },
        { "name": "tokenState", "isMut": true, "isSigner": false },
        { "name": "creator", "isMut": false, "isSigner": false },
        { "name": "tokenMint", "isMut": true, "isSigner": false }
      ],
      "args": [{ "name": "paused", "type": "bool" }]
    },
    {
      "name": "claimFees",
      "accounts": [
        { "name": "claimant", "isMut": true, "isSigner": true },
        { "name": "tokenState", "isMut": true, "isSigner": false },
        { "name": "tokenMint", "isMut": true, "isSigner": false },
        { "name": "feeVault", "isMut": true, "isSigner": false },
        { "name": "protocolFeeAccount", "isMut": true, "isSigner": false },
        { "name": "creatorFeeAccount", "isMut": true, "isSigner": false },
        { "name": "systemProgram", "isMut": false, "isSigner": false },
        { "name": "tokenProgram", "isMut": false, "isSigner": false }
      ],
      "args": []
    },
    {
      "name": "claimReferralRewards",
      "accounts": [
        { "name": "referrer", "isMut": true, "isSigner": true },
        { "name": "tokenState", "isMut": true, "isSigner": false },
        { "name": "tokenMint", "isMut": true, "isSigner": false },
        { "name": "feeVault", "isMut": true, "isSigner": false },
        { "name": "referrerWallet", "isMut": true, "isSigner": false },
        { "name": "systemProgram", "isMut": false, "isSigner": false }
      ],
      "args": []
    }
  ],
  "accounts": [
    {
      "name": "TokenState",
      "type": {
        "kind": "struct",
        "fields": [
          { "name": "creator", "type": "publicKey" },
          { "name": "tokenMint", "type": "publicKey" },
          { "name": "name", "type": "string" },
          { "name": "symbol", "type": "string" },
          { "name": "uri", "type": "string" },
          { "name": "curveState", "type": { "defined": "CurveState" } },
          { "name": "feeVault", "type": "publicKey" },
          { "name": "graduated", "type": "bool" },
          { "name": "ammPool", "type": { "option": "publicKey" } },
          { "name": "createdAt", "type": "i64" },
          { "name": "paused", "type": "bool" },
          { "name": "totalFeesCollected", "type": "u64" },
          { "name": "leverage", "type": "u8" },
          { "name": "direction", "type": { "defined": "Direction" } },
          { "name": "underlying", "type": { "defined": "Underlying" } },
          { "name": "oraclePriceAtLaunch", "type": "u64" }
        ]
      }
    },
    {
      "name": "FeeVault",
      "type": {
        "kind": "struct",
        "fields": [
          { "name": "tokenMint", "type": "publicKey" },
          { "name": "totalCollected", "type": "u64" },
          { "name": "creatorClaimed", "type": "u64" },
          { "name": "protocolClaimed", "type": "u64" },
          { "name": "creatorShareBps", "type": "u64" },
          { "name": "referrer", "type": { "option": "publicKey" } },
          { "name": "referralRewardsTotal", "type": "u64" },
          { "name": "referralRewardsClaimed", "type": "u64" }
        ]
      }
    },
    {
      "name": "UserReferral",
      "type": {
        "kind": "struct",
        "fields": [
          { "name": "user", "type": "publicKey" },
          { "name": "referredBy", "type": { "option": "publicKey" } },
          { "name": "totalReferralEarnings", "type": "u64" },
          { "name": "totalRewardsClaimed", "type": "u64" }
        ]
      }
    }
  ],
  "types": [
    {
      "name": "CurveState",
      "type": {
        "kind": "struct",
        "fields": [
          { "name": "virtualSolReserve", "type": "u64" },
          { "name": "virtualTokenReserve", "type": "u64" },
          { "name": "realSolReserve", "type": "u64" },
          { "name": "realTokenReserve", "type": "u64" },
          { "name": "k", "type": "u128" }
        ]
      }
    },
    {
      "name": "Direction",
      "type": {
        "kind": "enum",
        "variants": [{ "name": "Long" }, { "name": "Short" }]
      }
    },
    {
      "name": "Underlying",
      "type": {
        "kind": "enum",
        "variants": [
          { "name": "SolPerp" },
          { "name": "BtcPerp" },
          { "name": "EthPerp" },
          { "name": "DogePerp" }
        ]
      }
    }
  ],
  "events": [
    {
      "name": "TokenBought",
      "fields": [
        { "name": "tokenMint", "type": "publicKey", "index": false },
        { "name": "buyer", "type": "publicKey", "index": false },
        { "name": "solAmount", "type": "u64", "index": false },
        { "name": "tokensReceived", "type": "u64", "index": false },
        { "name": "price", "type": "u64", "index": false },
        { "name": "timestamp", "type": "i64", "index": false }
      ]
    },
    {
      "name": "TokenSold",
      "fields": [
        { "name": "tokenMint", "type": "publicKey", "index": false },
        { "name": "seller", "type": "publicKey", "index": false },
        { "name": "solAmount", "type": "u64", "index": false },
        { "name": "tokensSold", "type": "u64", "index": false },
        { "name": "price", "type": "u64", "index": false },
        { "name": "timestamp", "type": "i64", "index": false }
      ]
    },
    {
      "name": "TokenGraduated",
      "fields": [
        { "name": "tokenMint", "type": "publicKey", "index": false },
        { "name": "finalMarketCap", "type": "u64", "index": false },
        { "name": "timestamp", "type": "i64", "index": false }
      ]
    },
    {
      "name": "FeesClaimed",
      "fields": [
        { "name": "tokenMint", "type": "publicKey", "index": false },
        { "name": "claimer", "type": "publicKey", "index": false },
        { "name": "amount", "type": "u64", "index": false },
        { "name": "timestamp", "type": "i64", "index": false }
      ]
    },
    {
      "name": "TokenInitialized",
      "fields": [
        { "name": "tokenMint", "type": "publicKey", "index": false },
        { "name": "creator", "type": "publicKey", "index": false },
        { "name": "name", "type": "string", "index": false },
        { "name": "symbol", "type": "string", "index": false },
        { "name": "leverage", "type": "u8", "index": false },
        { "name": "direction", "type": "u8", "index": false },
        { "name": "underlying", "type": "u8", "index": false },
        { "name": "timestamp", "type": "i64", "index": false }
      ]
    },
    {
      "name": "ReferralRewardsClaimed",
      "fields": [
        { "name": "tokenMint", "type": "publicKey", "index": false },
        { "name": "referrer", "type": "publicKey", "index": false },
        { "name": "amount", "type": "u64", "index": false },
        { "name": "timestamp", "type": "i64", "index": false }
      ]
    }
  ],
  "errors": [
    { "code": 6000, "name": "NameTooLong", "msg": "Name too long (max 32 characters)" },
    { "code": 6001, "name": "SymbolTooLong", "msg": "Symbol too long (max 10 characters)" },
    { "code": 6002, "name": "AlreadyGraduated", "msg": "Token already graduated" },
    { "code": 6003, "name": "InsufficientLiquidity", "msg": "Insufficient liquidity in curve" },
    { "code": 6004, "name": "GraduationThresholdNotMet", "msg": "Graduation threshold not reached" },
    { "code": 6005, "name": "ContractPaused", "msg": "Contract is paused" },
    { "code": 6006, "name": "Unauthorized", "msg": "Unauthorized" },
    { "code": 6007, "name": "MathOverflow", "msg": "Math overflow" },
    { "code": 6008, "name": "InvalidAmount", "msg": "Invalid amount" },
    { "code": 6009, "name": "InvalidLeverage", "msg": "Invalid leverage (must be 2-10)" }
  ]
} as const

export type LeveragedMemeIDL = typeof IDL
